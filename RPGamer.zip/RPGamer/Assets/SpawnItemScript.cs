﻿using UnityEngine;

public class SpawnItemScript : MonoBehaviour
{
    public GameObject item;
    private Transform player;

    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
    }

    public void SpawnDroppedItem()
    {
        Vector2 playerPos = new Vector2(player.transform.position.x -1 ,player.position.y);
        Instantiate(item, playerPos, Quaternion.identity);
    }

}
