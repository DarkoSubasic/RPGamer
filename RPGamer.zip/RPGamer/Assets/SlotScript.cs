﻿using UnityEngine;

public class SlotScript : MonoBehaviour
{
    private InventoryScript inventory;
    public int i;

    private void Start()
    {
        inventory = GameObject.FindGameObjectWithTag("Player").GetComponent<InventoryScript>();
    }

    private void Update()
    {
        if (transform.childCount <= 0)
        {
            inventory.isFull[i] = false;
        }
    }

    public void DropItem()
    {
        foreach (Transform child in transform)
        {
            child.GetComponent<SpawnItemScript>().SpawnDroppedItem();
            GameObject.Destroy(child.gameObject);
        }
    }
    
}
