﻿using UnityEngine;

public class InventoryScript : MonoBehaviour
{
    public bool[] isFull;
    public GameObject[] slots;
    
}
