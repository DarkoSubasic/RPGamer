﻿
using UnityEngine;

public class EquipWeaponScript : MonoBehaviour
{
    private GameObject weaponSlot;
    private InventoryScript inventory;
    private ShooterScript shooterScript;
    public GameObject weapon;
    private PlayerController player;

    private void Start()
    {
        weaponSlot = GameObject.FindGameObjectWithTag("Weapon Slot");
        inventory = GameObject.FindGameObjectWithTag("Player").GetComponent<InventoryScript>();
        shooterScript = GameObject.FindGameObjectWithTag("Player").GetComponent<ShooterScript>();
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerController>();
    }
    

    public void EquipWeapon()
    {
        player.isArmed = true;
        //inventory.isFull[i] = true;
        Instantiate(weapon, weaponSlot.transform, false);
        Destroy(gameObject);
    }


}
