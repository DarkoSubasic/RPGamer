﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour {
    //Movement Variables
    public float speedForce;
    public Vector2 jumpVector;
    public bool isGrounded;
    public float maxHealth = 100f;
    public float curHealth = 100f;
    public HealthBarScript healthBar;
    
    
    private Rigidbody2D rb;
    private Animator anim;
    private float speed;

    public Transform grounder;
    public float radius;
    public LayerMask ground;
    public bool isArmed;

    void Start ()
    {
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        curHealth = maxHealth;
        healthBar.SetMaxHealth(100);
            
    }

    void FixedUpdate ()
    {
        if (curHealth<=0)
        {
            Debug.Log("You died!");
                        SceneManager.LoadScene(0);
        }
        //Moving Left/Right
        speed = speedForce;
     
        
        if (Input.GetKey(KeyCode.D))
        {
            speed = isGrounded ? speedForce : speedForce * 0.9f;
            rb.velocity = new Vector2(speed, rb.velocity.y);
            transform.localScale = new Vector3(1, 1, 1);
            anim.SetFloat("velocityX",1);
        }
        else if (Input.GetKey(KeyCode.A))
        {
            speed = isGrounded ? speedForce : speedForce * 0.9f;
            rb.velocity = new Vector2(-speed, rb.velocity.y);
            //transform.localScale = new Vector3(-1, 1, 1);
            anim.SetFloat("velocityX",1);
        }
        
        else if (!Input.GetKey(KeyCode.D)&&!Input.GetKey(KeyCode.A) && isGrounded)
        {
            rb.velocity = new Vector2(0, rb.velocity.y);
            anim.SetFloat("velocityX",0);
        }

        isGrounded = Physics2D.OverlapCircle(grounder.transform.position, radius, ground);
        anim.SetBool("grounded",isGrounded);
        
        if (Input.GetKey(KeyCode.Space) && isGrounded)
        {
            
            rb.AddForce(jumpVector,ForceMode2D.Force);
            
        }
        

    }

    public void TakeDamage(float damage)
    {
        curHealth -= damage;
        healthBar.SetHealth(curHealth);
    }

    private void OnDrawGizmos()
    {
        Gizmos.color=Color.white;
        Gizmos.DrawWireSphere(grounder.transform.position,radius);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Spikes"))
        {
            TakeDamage(20);
        }
    }
    
    private void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.CompareTag("deadly"))
        {
            TakeDamage(5);
        }
        if (other.gameObject.CompareTag("Enemy"))
        {
            TakeDamage(10);
        }
    }
}