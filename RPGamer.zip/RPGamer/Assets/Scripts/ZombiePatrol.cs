﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class ZombiePatrol : MonoBehaviour
{

    public Transform[] patrolPoints;
    public float speed=0.5f;
    public float timeOfAlertness=2f;
    public float sight = 3f;
    public float force =50f;
    public PlayerController player;
    
    private int currentPoint;
    private Animator anim;
    private Rigidbody2D rb;


    // Start is called before the first frame update
    void Start()    
    {
        StartCoroutine("Patrol");
        anim = GetComponent<Animator>();
        anim.SetBool("walking",true);
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        RaycastHit2D hit =Physics2D.Raycast(transform.position, transform.localScale.x * Vector2.right, sight);

        if (hit.collider!= null && hit.collider.tag== "Player")
        {
            rb.AddForce(Vector3.up*force + (hit.collider.transform.position-transform.position)*force);
            
        }
        

    }

    IEnumerator Patrol() 
    {
        while (true)
        {
            if (transform.position.x== patrolPoints[currentPoint].position.x)
            {
                currentPoint++;
                anim.SetBool("walking",false);
                yield return new WaitForSeconds(timeOfAlertness);
                anim.SetBool("walking",true);
            }

            if (currentPoint >= patrolPoints.Length)
            {
                currentPoint = 0;
            }

            transform.position = Vector2.MoveTowards(transform.position, new Vector2(patrolPoints[currentPoint].position.x, transform.position.y), speed);
            

            if (transform.position.x > patrolPoints[currentPoint].position.x)
            {
                transform.localScale = new Vector3(-1,1,1);
            }
            else if(transform.position.x < patrolPoints[currentPoint].position.x)
            {
                transform.localScale = Vector3.one;
            }
            yield return null;
            
        }

        
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Projectile")
        {
            Destroy(this.gameObject,0.1f);
        }
    }
    

    private void OnDrawGizmos()
    {
        Gizmos.color=Color.yellow;
        Gizmos.DrawLine(transform.position,transform.position+ Vector3.right * (transform.localScale.x * sight));
        
    }
}
