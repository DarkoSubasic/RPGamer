﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SimpleEnemyScript : MonoBehaviour
{
    public float velocity = 1f;
    public Transform sightStart;
    public Transform sightEnd;
    public bool colliding = false;
    public LayerMask detectWhat;
    public Transform weakness;
    
    
    private Rigidbody2D rb;
    private Animator anim;


    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        rb.velocity= new Vector2(velocity,rb.velocity.y);

       
        colliding = Physics2D.Linecast(sightStart.position, sightEnd.position,detectWhat);

        if (colliding)
        {
            transform.localScale = new Vector2(transform.localScale.x*-1,transform.localScale.y);
            velocity *= -1;
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color=Color.magenta;
        
        Gizmos.DrawLine(sightStart.position, sightEnd.position);
    }

    private void OnCollisionEnter2D(Collision2D col)
    {
        if (col.gameObject.tag == "Player")
        {
            float height = col.contacts[0].point.y - weakness.position.y;

            if (height>0)
            {
                Dies();
                col.rigidbody.AddForce(new Vector2(0,150));
            }
        }
    }

    void Dies()
    {
        anim.SetBool("killed",true);    
        Destroy(this.gameObject,0.5f);
        gameObject.tag = "neutralized";

    }
}
