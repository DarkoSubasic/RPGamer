﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TokenScript : MonoBehaviour
{
    public Text text;
    public int balance=10;



    public void SetToken()
    {
        text.text = (balance).ToString();
    }

    public void CollectToken()
    {
        balance++;
        text.text = (balance).ToString();
    }

}
