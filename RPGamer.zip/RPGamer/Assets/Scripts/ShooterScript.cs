﻿using UnityEngine;

public class ShooterScript : MonoBehaviour
{
    public GameObject bulletPrefab;
    private GameObject firePoint;
    private PlayerController player;


    private void Start()
    {
        player = GetComponent<PlayerController>();
    }

    private void Update()
    {
        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        float rotateY = 0f;

        if (mousePos.x < transform.position.x)
        {
            rotateY = 180f;
        }
        
        transform.eulerAngles = new Vector3(transform.rotation.x, rotateY, transform.rotation.z);
        
        if (Input.GetButtonDown("Fire1") && player.isArmed)
        {
            firePoint = GameObject.FindGameObjectWithTag("Fire Point");
            Shoot();
        }
    }

    private void Shoot()
    {
            Debug.Log("Shoot!");
            GameObject bullet = Instantiate(bulletPrefab, firePoint.transform.position, firePoint.transform.rotation);
            Destroy(bullet, 5f);
        
    }

   
}
