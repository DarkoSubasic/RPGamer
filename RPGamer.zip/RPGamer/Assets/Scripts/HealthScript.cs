﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthScript : MonoBehaviour
{
    public float maxHealth =100;
    public float curHealth =100;


    private void Update()
    {
        if (curHealth <= 0)
        {
            Destroy(this.gameObject);
        }
    }

    public void SetMaxHealth(float maXHealth)
    {
        maxHealth = maXHealth;
    }
    public void TakeDamage(float damage)
    {
        curHealth -= damage;
    }
}
