﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SwitchScript : MonoBehaviour
{
    private Animator anim;
    public DoorTrigger[] doorTrig;
    new Collider2D collider;

    public bool sticks;
    // Start is called before the first frame update
    void Start()
    {
        collider = GetComponent<Collider2D>();
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerStay2D()
    {
        anim.SetBool("goDown",true);

        foreach (DoorTrigger trigger in doorTrig)
        {
            trigger.Toggle(true); 
        }

        if (sticks)
        {
            collider.enabled = false;
        }
        
        
    }
    
    void OnTriggerExit2D()
    {
        if (sticks)
            return;
        anim.SetBool("goDown",false);
        
        foreach (DoorTrigger trigger in doorTrig)
        {
            trigger.Toggle(false); 
        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color=Color.cyan;
        foreach (DoorTrigger trigger in doorTrig)
        {
            Gizmos.DrawLine(transform.position,trigger.transform.position);
        }
        
    }
}
