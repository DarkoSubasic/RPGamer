﻿
using System;
using UnityEngine;

public class BulletScript : MonoBehaviour
{

    public float bulletSpeed;
    public float bulletDamage;

    private Rigidbody2D rb;
    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        Vector2 force = transform.right * bulletSpeed;
        rb.AddForce(force,ForceMode2D.Impulse);    
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        Destroy(this.gameObject);
        if(other.gameObject.GetComponent<HealthScript>()!= null)
        other.gameObject.GetComponent<HealthScript>().TakeDamage(bulletDamage);
    }
}
