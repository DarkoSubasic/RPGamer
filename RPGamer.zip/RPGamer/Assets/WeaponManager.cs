﻿using UnityEngine;

public class WeaponManager : MonoBehaviour
{
    public GameObject activeWeapon;
    private GunScript wpn;
    
    
    // Start is called before the first frame update
    void Start()
    {
        wpn = activeWeapon.GetComponent<GunScript>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
