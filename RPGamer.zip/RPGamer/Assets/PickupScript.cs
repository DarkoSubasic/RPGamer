﻿using UnityEngine;

public class PickupScript : MonoBehaviour
{
  private InventoryScript inventory;
  public GameObject itemButton;
  private PlayerController player;

  private void Start()
  {
    inventory = GameObject.FindGameObjectWithTag("Player").GetComponent<InventoryScript>();
    player = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerController>();
    
  }

  private void Update()
  {
    if(Input.GetKeyDown(KeyCode.Q) && CompareTag("Equippable"))
    {
      UnequipItem();
    }
  }

  private void OnTriggerEnter2D(Collider2D other)
  {
    if (other.CompareTag("Player"))
    {
      for (int i = 0; i < inventory.slots.Length; i++)
      {
        if (inventory.isFull[i] == false)
        {
          inventory.isFull[i] = true;
          Instantiate(itemButton, inventory.slots[i].transform, false);
          Destroy(gameObject);
          break;
        }
      }
    }
  }

  private void UnequipItem()
  {
    for (int i = 0; i < inventory.slots.Length; i++)
    {
      if (inventory.isFull[i] == false)
      {
        inventory.isFull[i] = true;
        Instantiate(itemButton, inventory.slots[i].transform, false);
        player.isArmed = false;
        Destroy(gameObject);
        break;
      }
    }
  }
}
